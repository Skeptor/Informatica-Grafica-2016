#ifndef _CUBO
#define _CUBO
#include "objeto3D.h"

class Cubo : public Objeto3D{
public:
	Cubo();
	
};

#endif