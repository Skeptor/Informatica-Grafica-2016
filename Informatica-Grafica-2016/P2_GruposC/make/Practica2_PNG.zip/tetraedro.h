#ifndef _PIRAMIDE
#define _PIRAMIDE
#include "objeto3D.h"

class Tetraedro : public Objeto3D{
public:
	Tetraedro();
	Tetraedro(double tam);
	
};

#endif