#include "color.h"

color::color(){

}

color::dibujar()const{
	glColor4f(r,g,b,valor);
}